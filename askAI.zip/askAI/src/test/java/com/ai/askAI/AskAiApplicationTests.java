package com.ai.askAI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AskAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
