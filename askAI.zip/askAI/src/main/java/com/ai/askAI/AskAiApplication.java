package com.ai.askAI;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AskAiApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(AskAiApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

	}
}
